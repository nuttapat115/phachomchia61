@extends('layouts.app')

@section('content')
   <div class="container-fluid">
      <div class="row">
          <div class="embed-responsive embed-responsive-16by9">
              <iframe class="embed-responsive-item" allow="geolocation; microphone; camera" src="https://meenkx.github.io/ScanPhachomchia61.github.io/" allowfullscreen></iframe>
          </div>
      </div>
   </div>

@endsection
