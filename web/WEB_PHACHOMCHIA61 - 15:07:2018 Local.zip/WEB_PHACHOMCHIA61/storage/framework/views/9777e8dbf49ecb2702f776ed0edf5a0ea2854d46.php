<?php $__env->startSection('content'); ?>
   <div class="container-fluid">
      <div class="row">
          <div class="embed-responsive embed-responsive-16by9">
              <iframe class="embed-responsive-item" allow="geolocation; microphone; camera" src="https://meenkx.github.io/ScanPhachomchia61.github.io/" allowfullscreen></iframe>
          </div>
      </div>
   </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>